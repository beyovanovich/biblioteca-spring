package com.example.QuickOrder.service;

import com.example.QuickOrder.model.*;
import com.example.QuickOrder.repository.PedidoRepository;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Se encarga de validar datos y coordinar las operaciones con el repositorio.
 */

@Service
public class PedidoService {

    private final PedidoRepository repo;

    public PedidoService(PedidoRepository repo) {
        this.repo = repo;
    }

    /**
     * Crea un nuevo pedido.
     * Valida los campos obligatorios y les pone la fecha automáticamente.
     */

    public Pedido crear(@NotNull Pedido p) {
        // Validar nombre obligatorio
        if (p.getNombreCliente() == null || p.getNombreCliente().isEmpty()) {
            throw new RuntimeException("Nombre obligatorio");
        }
        // Validar monto mayor a cero
        if (p.getMontoTotal() <= 0) {
            throw new RuntimeException("Monto no valido");
        }
        // Asignar fecha actual
        p.setFechaPedido(LocalDate.now());
        // Guardar en repositorio
        return repo.guardar(p);
    }
    /**
     * Retorna todos los pedidos.
     */
    public List<Pedido> listar() {
        return repo.listar();
    }
    /**
     * Obtiene un pedido por ID.
     */
    public Pedido obtener(Long id) {
        return repo.buscar(id)
                .orElseThrow(() -> new RuntimeException("No existe"));
    }
    /**
     * Actualiza los datos de un pedido existente.
     */
    public Pedido actualizar(Long id, Pedido nuevo) {
        Pedido p = obtener(id);

        p.setNombreCliente(nuevo.getNombreCliente());
        p.setDescripcion(nuevo.getDescripcion());
        p.setEstado(nuevo.getEstado());
        p.setTipoPedido(nuevo.getTipoPedido());
        p.setMontoTotal(nuevo.getMontoTotal());

        return p;
    }
    /**
     * Elimina un pedido por ID.
     */
    public void eliminar(Long id) {
        obtener(id);
        repo.eliminar(id);
    }
    /**
     * Filtra pedidos según su estado.
     */
    public List<Pedido> filtrarPorEstado(Estado estado) {
        return repo.listar()
                .stream()
                .filter(p -> p.getEstado() == estado)
                .collect(Collectors.toList());
    }
}
