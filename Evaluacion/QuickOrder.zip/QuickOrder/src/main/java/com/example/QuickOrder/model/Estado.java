package com.example.QuickOrder.model;

/**
 * Enum que define los estados posibles de un pedido.
 */

public enum Estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}
