package com.example.QuickOrder.repository;

import com.example.QuickOrder.model.Pedido;
import org.springframework.stereotype.Repository;

import java.util.*;
/**
 * Repositorio que funciona como una base de datos.
 * Maneja el almacenamiento de pedidos usando una lista.
 */
@Repository
public class PedidoRepository {

    private List<Pedido> lista = new ArrayList<>();
    private Long id = 1L;

    /**
     * Guarda un nuevo pedido asignando un ID automático.
     */

    public Pedido guardar(Pedido p) {
        p.setId(id++);
        lista.add(p);
        return p;
    }

    /**
     * Retorna todos los pedidos almacenados.
     */

    public List<Pedido> listar() {
        return lista;
    }

    /**
     * Busca un pedido por su ID.
     */

    public Optional<Pedido> buscar(Long id) {
        return lista.stream().filter(p -> p.getId().equals(id)).findFirst();
    }

    /**
     * Elimina un pedido por ID.
     */

    public void eliminar(Long id) {
        lista.removeIf(p -> p.getId().equals(id));
    }
}
