package com.example.QuickOrder.controller;

import com.example.QuickOrder.model.*;
import com.example.QuickOrder.service.PedidoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Controlador REST encargado de exponer los ENDPOINTS de la API.
 * RECIBE LAS PETICIONES
 */

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService service;
    /**
     * Constructor que inyecta el servicio de pedidos.
     */

    public PedidoController(PedidoService service) {
        this.service = service;
    }

    /**
     * Crea un nuevo pedido en el sistema.
     * @param p datos del pedido enviados en el body
     * @return pedido creado con código
     */

    @PostMapping
    public ResponseEntity<?> crear (@RequestBody Pedido p) {
        return ResponseEntity.status(201).body(service.crear(p));
    }

    /**
     * Retorna la lista completa de pedidos.
     * @return lista de pedidos
     */

    @GetMapping
    public List<Pedido> listar() {
        return service.listar();
    }

    /**
     * Obtiene un pedido por su ID.
     * @param id identificador del pedido
     * @return pedido encontrado
     */

    @GetMapping("/{id}")
    public ResponseEntity<?> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(service.obtener(id));
    }

    /**
     * Actualiza un pedido existente.
     * @param id ID del pedido a actualizar
     * @param p nuevos datos del pedido
     * @return pedido actualizado
     */

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @RequestBody Pedido p) {
        return ResponseEntity.ok(service.actualizar(id, p));
    }

    /**
     * Elimina un pedido por su ID.
     * @param id identificador del pedido
     * @return respuesta sin contenido
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Filtra pedidos por estado.
     * @param estado estado a buscar
     * @return lista de pedidos que coinciden
     */

    @GetMapping("/estado/{estado}")
    public List<Pedido> filtrar(@PathVariable Estado estado) {
        return service.filtrarPorEstado(estado);
    }


}
