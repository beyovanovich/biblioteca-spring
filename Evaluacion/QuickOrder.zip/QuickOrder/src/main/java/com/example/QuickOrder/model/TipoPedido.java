package com.example.QuickOrder.model;

/**
 * Enum que define los tipos de pedido disponibles.
 */

public enum TipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS
}
